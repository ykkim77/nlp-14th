from sklearn.preprocessing import OneHotEncoder
import numpy as np
from .hgtk.text import compose, decompose
from .hgtk.checker import is_hangul, is_jamo_style_hangul
from .hgtk.const import JAMO, SPECIAL, DEFAULT_COMPOSE_CODE, NUMBER


class Korean():
    def __init__(self, ko_text):
        if not isinstance(ko_text, str):
            if (
                isinstance(ko_text, list) or
                isinstance(ko_text, np.ndarray)
            ):
                ko_text = "".join(ko_text)
            else:
                raise ValueError("ko_text에는 string 형이 들어가야 합니다.")

        if not is_hangul(ko_text):
            raise ValueError("ko_text에 한글이 아닌 다른 문자가 들어갔습니다.")

        if is_jamo_style_hangul(ko_text):
            self.raw = compose(ko_text)
            self.jamo = ko_text
        else:
            self.raw = ko_text
            self.jamo = decompose(ko_text)

    def __repr__(self):
        return self.raw


class JamoEncoder(OneHotEncoder):
    def __init__(self):
        super().__init__()
        all_chars = list(
            set(JAMO + SPECIAL + (DEFAULT_COMPOSE_CODE,) + NUMBER))
        char_array = np.array(all_chars).reshape(-1, 1)
        super().fit(char_array)

    def transform(self, X):
        if isinstance(X, str):
            char_arr = np.array(list(X)).reshape(-1, 1)
            return super().transform(char_arr).toarray()
        elif isinstance(X, list):
            if isinstance(X[0], str) or isinstance(X[0], list):
                results = []
                for x in X:
                    char_array = np.array(list(x)).reshape(-1, 1)
                    result = super().transform(char_array).toarray()
                    results.append(result)
                try:
                    return np.stack(results)
                except:
                    return results
            else:
                raise ValueError("적절하지 못한 데이터 타입이 들어왔습니다.")

        elif isinstance(X, np.ndarray):
            results = []
            for x in X:
                char_array = np.array(list(x)).reshape(-1, 1)
                result = super().transform(char_array).toarray()
                results.append(result)
            try:
                return np.stack(results)
            except:
                return results
        else:
            raise ValueError("적절하지 못한 데이터 타입이 들어왔습니다.")

    def inverse_transform(self, X):
        X_shape = X.shape

        vec_size = len(self.categories_[0])
        X = X.reshape(-1, vec_size)
        return super().inverse_transform(X).reshape(X_shape[:-1])
